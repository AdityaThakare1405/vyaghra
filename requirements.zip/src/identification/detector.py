"""
Detection/crop module: isolates the most likely "subject region" (flank
area) of an image, using a contour-based heuristic rather than a trained
object detector.
"""

import cv2
import numpy as np


def detect_and_crop(image_path: str):
    image = cv2.imread(image_path)
    if image is None:
        return None, False

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blurred, 50, 150)

    kernel = np.ones((7, 7), np.uint8)
    dilated = cv2.dilate(edges, kernel, iterations=2)

    contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if not contours:
        return None, False

    largest = max(contours, key=cv2.contourArea)
    area = cv2.contourArea(largest)
    image_area = image.shape[0] * image.shape[1]

    if area < 0.02 * image_area:
        return None, False

    x, y, w, h = cv2.boundingRect(largest)
    cropped = image[y:y + h, x:x + w]

    crop_path = image_path.rsplit(".", 1)[0] + "_crop.jpg"
    cv2.imwrite(crop_path, cropped)

    return crop_path, True


if __name__ == "__main__":
    from src.config import SAMPLES_DIR
    from src.ingestion.scanner import find_images

    images = find_images(SAMPLES_DIR)
    tiger_images = [img for img in images if "tiger" in str(img)]

    for img in tiger_images[:8]:
        crop_path, usable = detect_and_crop(str(img))
        print(f"{img.name}: crop={crop_path}, usable={usable}")